import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>JavaScript and React.js</h1>
      <p>Basic web dev reat js Bootcamps</p>
    </div>
  );
}
export default Info;
